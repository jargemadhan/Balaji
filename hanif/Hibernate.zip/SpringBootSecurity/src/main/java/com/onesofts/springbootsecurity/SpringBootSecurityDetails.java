package com.onesofts.springbootsecurity;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
@Configuration
@EnableWebSecurity
public class SpringBootSecurityDetails {
	@Bean
	public UserDetailsService userDetails(PasswordEncoder encoder) {
		
		UserDetails owner=User.withUsername("owner")
		        .password(encoder.encode("owner"))
		        .roles("OWNER","MANAGER","USER").build();
		
		UserDetails admin=User.withUsername("admin")
				.password(encoder.encode("admin"))
				.roles("MANAGER","USER").build();
		
		UserDetails user=User.withUsername("user")
				.password(encoder.encode("user"))
				.roles("USER").build();
		
		return new InMemoryUserDetailsManager(admin,user,owner);
	    }

	@Bean
	public PasswordEncoder pass() {
		return new BCryptPasswordEncoder();
	    }
	@Bean
	public SecurityFilterChain security(HttpSecurity http)throws Exception {
		return http.csrf().disable()
				.authorizeHttpRequests()
				.requestMatchers("/admin").hasRole("ADMIN")
				.requestMatchers("/user").hasRole("USER")
				.requestMatchers("/owner").hasRole("OWNER")
				.anyRequest().authenticated()
				.and()
				.formLogin()
				.and()
				.build();
	  }
}
