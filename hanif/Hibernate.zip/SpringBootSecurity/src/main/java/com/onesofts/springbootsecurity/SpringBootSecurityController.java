package com.onesofts.springbootsecurity;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/login")
public class SpringBootSecurityController {
	@GetMapping(value="/owner")
	@PreAuthorize("hasAuthority('OWNER')")
	public String owner() {
		return "Welcome owner";
	}
	@GetMapping(value="/admin")
	@PreAuthorize("hasAuthority('ADMIN')")
	public String admin() {
		return "Welcome admin";
	}
	@GetMapping(value="/user")
	@PreAuthorize("hasAuthority('USER')")
	public String user() {
		return "Welcome user";
	}
	}


